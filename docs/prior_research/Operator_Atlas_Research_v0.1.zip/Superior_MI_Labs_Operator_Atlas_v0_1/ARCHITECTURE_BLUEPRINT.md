# Superior MI Labs — Operator Atlas
## Proposed mathematical-organization architecture | Research design v0.1 | 2026-10-19

**Status:** Concept proposal with reproducible synthetic falsification probes. Not a trained language model, deployable general intelligence, validated breakthrough, or performance guarantee.

## 0. Scientific hypothesis
A heterogeneous *operator atlas* can learn, select, and execute different compact representations of neural transformations, while retaining irreducible information in exact or explicit stores, and perform better on at least one quality–storage–latency Pareto frontier than strong, equally resourced conventional networks. It is a conditional, experimentally falsifiable hypothesis.

Do **not** presume all facts, weights, or task structure are compressible. Treat the format choice as a learned or measured decision. Preserve input-dependent uncertainty and multiple information timescales.

## 1. Design commitments
1. One authoritative evidence/document store, content-addressed and versioned. Derivative vector indices, embeddings, summaries, and trained models never overwrite provenance.
2. One canonical operator representation and training contract. The execution planner chooses a CPU/GPU implementation, not a separate scientific definition.
3. Model weights / generated operator factors, document facts, runtime recurrent/KV state, and cached computation are distinct state domains, each with a clearly defined owner.
4. Do not reconstruct full weight matrices on inference hot paths unless a measured execution plan explicitly wins.
5. Quantized dense and exact algorithmic fallback are first-class choices, not embarrassing exceptions.
6. New equations/experts are candidates until validated; deploy atomically, preserve rollback.
7. Real-world task loss, calibration, storage bits, bytes moved, latency, energy (when metered), and OOD generalization determine progress; parameter count alone does not.

## 2. Core graph
```mermaid
flowchart TD
    IN[Books / chat / docs / sensors / tables] --> ING[Ingestion + modality parsers]
    ING --> SRC[(Immutable source + event provenance)]
    ING --> ENC[Encoders + typed observations]
    ENC --> IDX[(Retrieval index / derived embeddings)]
    SRC --> IDX
    ENC --> LEARN[Learning and representation candidates]
    LEARN --> DISC[Equation / operator search]
    DISC --> VAL[Independent validation + cost evaluation]
    VAL -->|qualified| REG[(Versioned operator atlas)]
    VAL -->|reject| SRC
    USER[User prompt] --> TKN[Tokenizer + contextual model]
    TKN --> PLAN[Operator selection + task planning]
    IDX --> PLAN
    REG --> PLAN
    PLAN --> IR[Typed operator DAG]
    IR --> EXEC[Hardware-adaptive execution]
    EXEC --> DECODE[Contextual decoder / output head]
    DECODE --> OUT[Response + citations / uncertainty]
    EXEC --> METRICS[Real performance / reliability metrics]
    METRICS --> VAL
```

## 3. State owners and precise definitions
- **Source authority:** uploaded documents, claims, provenance, consent, revisions, deletion rights, access controls. Immutable revisions with tombstones and retention policy.
- **Derived retrieval memory:** term indices, embeddings, domain graphs; rebuildable from source authority; version-scoped.
- **Model state:** learned encoder/decoder parameters, mathematical basis functions, layer coordinates, residual tensors. Frozen by version during active inference.
- **Execution state:** KV/recurrent state with model, tokenizer, prefix, device and revision identities.
- **Observation memory:** task traces and measured benchmark statistics; append-only evidence, no claim of ground-truth correctness without an oracle.
- **Operator atlas:** registry of candidate and qualified operator forms, their domain and error constraints; no separate model-fact database.

## 4. Representation family (the choice is empirical)
For layer l and input x, a representative conditional transformation is:

\[h_{l+1}=h_l+\sigma(\sum_{m\in S_l(x)}g_{lm}(x) A_{lm}\,\phi_m(B_{lm}h_l)+R_l h_l+b_l)\]

- A/B: trainable factors; \(\phi_m\) may be an identity, spline, Fourier features, or measured operator kernel.
- g: initially fixed weights. Only later add context-conditioned routing after showing necessity.
- R: actually sparse or blockwise residual values, indices and overhead counted; not a dense masked tensor.
- Orthogonal/coordinate transformations learned when useful, not assumed to carry intrinsic semantic meaning.
- Operator variants: dense FP32/BF16/FP16; packed 8/4/ternary quantized; factorized; blockwise sparse; low rank + sparse; tensor train; structured convolution/Fourier; coordinate field generator; explicit symbolic program.

An alternative coordinate formulation is \(W_{lij}\simeq f_\theta(l,i,j,z)+R_{lij}\). This may be compact in memory but very expensive to evaluate elementwise. Prefer direct operator application; materialize only selected blocks when benchmarked.

**This is an architecture search space, not an instruction to implement all variants at once.** First implement `dense`, `packed_quantized`, `factorized`, `factorized_plus_sparse`; leave the rest as documented research candidates.

## 5. Automatic equation discovery — actual algorithm, not rhetoric
1. Read source data with type, units, coordinate semantics, admissible domain, evidence provenance and version.
2. Partition based on measured residual, local statistics and tasks, not arbitrary contiguous token IDs.
3. Generate a small list of candidate representation families from registered operators: low rank, low-rank+sparse, fixed symbolic grammar, and dense/quantized control.
4. Fit their coefficients and representation parameters on a training split, optionally end-to-end with decoder/task loss.
5. Choose via a Pareto test: held-out and shifted-task error versus **serialized** parameter+index+metadata bits and measured runtime. A conceptual MDL objective is `task_NLL + λ·stored_bits + μ·latency + ν·OOD_penalty`.
6. Explicitly reject candidate equations if they do not beat standard representations on relevant constraints; keep raw/quantized data.
7. Publish a versioned artifact; monitor drift, retain rollback, and revisit the candidate when enough new evidence accumulates.

Symbolic regression finds explicit expressions only *within the allowable grammar*. A nonlinear hypernetwork provides a flexible functional expression but may be opaque. Neither is a guarantee of compressibility or correct law discovery. Add type/unit/symmetry constraints where the domain supplies them.

## 6. Ingesting a new book or new information
- Extract authorized text, page/section spans, tables, figures if supported, and rights metadata.
- Save the authoritative text + content hash + source and reader permissions. Build deterministic chunk spans and retrieval indices.
- Extract candidate entities, relations, claims and formulas, retaining evidence and uncertainty.
- **Immediately:** a decoder can answer questions using retrieved book passages. This is retrieval, not a weight update.
- **Optional offline consolidation:** make training tasks from permissioned content, train adapter/basis updates, compare old/new held-out quality and citation fidelity; reject regressions and unauthorized mixing across tenants.
- If a book teaches a smooth physical law, symbolic regression might discover a compact equation under correct assumptions. If it teaches a unique author's name or invented event, that is typically explicit source-backed factual data, not something that must be interpolated into a formula.
- On conflicting sources, present evidence, uncertainty and temporal qualifiers. Never let confidence alone override provenance.

## 7. Neural inference and answer generation
- Use a real autoregressive decoder; otherwise the product is a classifier with canned answers.
- Token encoder produces contextual activations; attention or recurrent context mechanism tracks discourse.
- Operators selected per layer/region apply factors or structured kernels to activations. Choices can be static at first; gating is introduced when it shows a benefit.
- For source-specific queries, retrieval provides evidence; generation is conditioned on evidence; citations map to authoritative spans.
- Token scores are decoded sequentially; computational state is preserved with valid model/prefix identities. A saved state is not semantic knowledge and is not safe across arbitrary prompt edits.
- Repeated neural outputs might still hallucinate; require external verification where exact checks are possible.

## 8. Actual software subsystems
1. `records`: authoritative bytes/claims/provenance + content-addressed revision events.
2. `encoders`: typed observations from modalities; tokenizer and canonical preprocessing.
3. `operators`: strict shape/dtype/gradient/serialization semantics; reference implementations.
4. `discover`: representation family proposal and coefficient training; stays offline.
5. `qualify`: tests, out-of-distribution probes, memory accounting, and timing.
6. `registry`: atomic qualified operator artifact versions and rollback.
7. `compiler`: typed DAG -> device-specific execution plans via reproducible kernels.
8. `model`: one encoder/decoder runtime, contextual state and retrieval interface.
9. `eval`: evidence ledger and deterministic experiment replay.
10. `api`: stable local/remote inference + ingest + explain endpoints; thin browser inspector.

Minimal public API concepts (schemas later):
```
POST /v1/observations/ingest   -> {source_revision, derived_index_revision}
POST /v1/models/train          -> {candidate_run_id}              # offline job
POST /v1/operators/qualify     -> {qualification_report_id}
POST /v1/operators/publish     -> {artifact_revision}             # controlled
POST /v1/inference/generate    -> token stream + model/evidence revisions
GET  /v1/traces/{request_id}   -> typed operator DAG and measurements
```
These are design contracts, not implemented endpoints. Authorization, queueing, revision expectations, and confidentiality must be explicit before a production release.

## 9. Hardware-aware runtime
Use hardware discovery as *data*: available storage tiers and bandwidth, achievable per-kernel throughput, supported dtypes, transfer costs, latency and thermal limits. The engine chooses execution plans by measurement, not device brand.
- CPU: sparse and small models, exact algorithms, memory capacity.
- GPU: large batched factors, attention, dense/quantized matmuls; fuse where advantageous.
- Storage: source archives, cold experts, immutable checkpoints; prefetch if justified.
- Future accelerators: backend adapters implementing operator contracts, not bespoke scientific models.
- Optimize a measured upper-bound style model `T ≳ max(FLOPs/effective_compute, bytes_moved/effective_bandwidth)+launches+transfers`; never report its inverse as observed tokens per second.
- Compare serving metrics at prefill and decode, batch sizes 1 and N, context length, cold/warm model states, streaming behavior, and cost per correct task.

## 10. Real-world uses, with a prioritization rationale
- **Scientific fields/time-series:** structured sensor data, PDE solution surrogates, spatial measurement compression; strongest candidate for analytic basis discovery, but must validate rare events and drift.
- **On-device AI:** compressed operators may save memory and bandwidth if a rank/quantized format preserves quality and kernels are efficient.
- **Document knowledge assistants:** book ingestion, source-grounded retrieval, updated facts; predominantly explicit data/retrieval with optional later model consolidation—not an equation compressor for arbitrary prose.
- **Industrial instrumentation:** efficient local anomaly detection; exceptions are often important, so lossless incident/event retention.
- **Modality adapters:** shared mathematical bases across related tasks may reduce repeated parameters; cross-modal alignment must be learned and tested.
- **Model distribution:** sharing compact operator dictionaries among compatible model variants could reduce stored copies and transfer, but inter-model coordinate alignment is a major research problem.

## 11. Experiment program and kill criteria
**E0**: synthetic codec selection, equation family search, shift and sparse residual; current package. This is mechanism evidence, not an LLM result.
**E1**: 1–5M parameter autoregressive tiny language model; compare standard small dense, size-matched smaller dense, quantized dense, native factorized, factorized+true sparse. Multiple seeds and unseen corpora; same data/training budgets.
**E2**: 10–30M language model, native blockwise learned coordinate/basis, explicit serialized size and actual decode kernels.
**E3**: 30–150M (conditional on E2), mixed tasks/books/multilingual text, OOD, long context; commercial-grade kernel baselines.
**E4**: >=1B only if previous E stages show clear quality/storage/runtime Pareto gains and compute is available. Train/serve in distributed or single-node settings; independent reproduction.

Hard gates: no worse than pre-registered quality tolerance relative to a **matched-budget** strong baseline, strictly better at least one measured resource axis (bytes/latency/energy), no hidden accuracy collapses on OOD, no uncounted generator or index costs, reproducible across at least five seeds at small scales. Negative results should be published.

## 12. Simulation findings (2026-10-19)
Five RNG seeds per case, synthetic 48×48 FP32 matrices; decoder proposals selected by held-out linear output error. Storage shown is ideal coefficient+index payload, not actual packed file footprint.
- rank2 structured: rank2, 768 B vs 9216 B dense (12x), test relative output error ~5.7e-8.
- rank6 structured: rank6, 2304 B (4x), error ~7.3e-8.
- rank2 with 18 explicit irregular values: robust rank2 + 24 sparse slots, 960 B (9.6x), error ~5.6e-8. Plain SVD+top-k wasn't sufficient; robust alternating factor+exception estimation was needed.
- unstructured random: strict 0.5% output-error limit -> full 9216 B; relaxed 2% limit -> int8 2308 B, test relative error ~0.77%.
- equation discovery from supplied 8-function grammar, 60 noisy observations: recovered `1 + x² + sin(2x)` term family in 5/5 runs; mean RMSE 0.005 vs mean predictor 1.642. For random targets, equation fit (1.036 RMSE) worse than mean predictor (1.022).
- input subspace (4D inside 48D): compact factor 1536 B vs dense 9216 B, mean familiar-output relative error ~6.85e-8; shifted random directions ~96% relative error. This is the sharpest warning about 'quality on familiar inputs'.

### Interpretation limits
The synthetic generator is built to favor candidate families; its results cannot establish benefits on natural language, training from scratch, GPUs, true source information encoding, automatic architecture search, or new knowledge acquisition. No wall-clock execution benchmark is represented here. Candidate selection uses the reference matrix and validation probes; the equation search uses a predefined grammar and synthetic data.

## 13. Prior work to compare directly
- NeRN (ICLR 2023), coordinate-conditioned neural representations of network weights: https://arxiv.org/abs/2212.13554
- ASVD, activation-aware matrix compression: https://arxiv.org/abs/2312.05821
- BitNet (JMLR 2025), low-precision native training: https://mlanthology.org/jmlr/2025/wang2025jmlr-bitnet/
- AI Feynman, symbolic regression under physics priors: https://pmc.ncbi.nlm.nih.gov/articles/PMC7159912/
- 2026 scientific implicit representations: https://www.nature.com/articles/s42256-026-01290-0
- Mamba-2 structured state-space duality: https://proceedings.mlr.press/v235/dao24a.html

## 14. Next exact implementation step
Create **one canonical `LinearOperator` contract** with `shape`, `dtype`, `apply`, `serialize`, `bit_cost`, `bytes_moved_estimate`, `device_support`, `grad`, and `version`. Implement Dense, PackedInt8, Factorized, and RealSparseCorrection under this contract; property-test equivalent shapes and gradients. Then implement **one** tiny autoregressive decoder whose linear operators are swappable via a manifest. Do not build a second graph authority, custom file store, autonomous agent or large UI before evidence exists.
