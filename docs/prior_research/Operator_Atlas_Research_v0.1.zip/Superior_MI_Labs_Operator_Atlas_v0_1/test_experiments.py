"""Small falsification/consistency tests for synthetic Atlas research probes."""
import json
import unittest
from pathlib import Path
import numpy as np
from experiments import BASIS, encode_candidates, discover, predict_equation, source_tile, relative_error

class TestOperatorAtlas(unittest.TestCase):
    def test_candidate_includes_uncompressed_fallback(self):
        W=np.random.default_rng(4).normal(size=(48,48)).astype('float32')
        candidates=encode_candidates(W)
        assert candidates[0][0]=='fp32'
        assert candidates[0][2]==48*48*4
        np.testing.assert_array_equal(candidates[0][1],W)

    def test_rank2_known_signal_recovers(self):
        rng=np.random.default_rng(5)
        W=source_tile('rank2',rng).astype('float32')
        byname={name:(A,b) for name,A,b in encode_candidates(W)}
        A,bytes_=byname['rank2']
        self.assertEqual(bytes_,768)
        self.assertLess(relative_error(W,A),1e-5)

    def test_sparse_exception_reconstruction(self):
        rng=np.random.default_rng(6)
        W=source_tile('rank2+sparse',rng).astype('float32')
        byname={name:(A,b) for name,A,b in encode_candidates(W)}
        A,bytes_=byname['robust-rank2+sparse24']
        self.assertEqual(bytes_,960)
        self.assertLess(relative_error(W,A),1e-4)

    def test_irregular_dense_is_necessary_at_strict_error(self):
        rng=np.random.default_rng(7)
        W=source_tile('random',rng).astype('float32')
        X=rng.normal(size=(48,128))
        ok=[(name,n) for name,A,n in encode_candidates(W) if relative_error(W@X,A@X)<=.005]
        self.assertEqual(min(ok,key=lambda x:x[1])[0],'fp32')

    def test_symbolic_search_reconstructs_in_grammar(self):
        rng=np.random.default_rng(8)
        x=rng.uniform(-2,2,size=60)
        y=1.4-.65*x*x+2.2*np.sin(2*x)
        cols,coefs=discover(x,y)
        self.assertEqual({BASIS[i][0] for i in cols},{'1','x²','sin(2x)'})
        self.assertLess(float(np.max(np.abs(predict_equation(x,cols,coefs)-y))),1e-10)

    def test_distribution_shift_breaks_subspace_reconstruction(self):
        rng=np.random.default_rng(9)
        W=rng.standard_normal((48,48))
        U,_=np.linalg.qr(rng.standard_normal((48,4)))
        approx=(W@U)@U.T
        xin=U@rng.normal(size=(4,100))
        xout=rng.normal(size=(48,100))
        self.assertLess(relative_error(W@xin,approx@xin),1e-10)
        self.assertGreater(relative_error(W@xout,approx@xout),.75)

    def test_recorded_results_match(self):
        results=json.loads((Path(__file__).parent/'results.json').read_text())
        self.assertEqual(results['codec']['0.005']['random']['selected'],['fp32']*5)
        self.assertEqual(results['discovery']['structured']['learned_terms'],['1,x²,sin(2x)']*5)

if __name__=='__main__':
    unittest.main(verbosity=2)
