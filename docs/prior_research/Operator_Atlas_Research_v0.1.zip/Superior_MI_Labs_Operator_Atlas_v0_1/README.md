# Superior MI Labs — Operator Atlas v0.1

An original research proposal **to be tested**, not a proven new neural architecture. This bundle contains the design blueprint, executable synthetic experiments and seven unit tests.

## Reproduce
Python 3.10+, NumPy. `python experiments.py` regenerates `results.json` and three CSV files. `python -m unittest test_experiments.py -v` runs the seven tests. Use `OPENBLAS_NUM_THREADS=1` for predictable local workload scheduling; recorded results are from Python with NumPy on CPU.

## Reproducibility and claims
- Synthetic matrices 48×48 with seeded random generators; five seeds per condition.
- Representation selection constrained by held-out validation output error, tested on independently sampled inputs.
- All byte figures are ideal FP32 coefficient payload and explicit sparse index/value assumptions; metadata, kernel workspace, actual serialized files and training-state storage not included.
- No real neural network or large-language-model learning, inference speed, energy use or task accuracy benchmark was performed by these scripts.
- Symbolic discovery searches a **predefined** eight-function grammar and fits coefficients; this is not open-ended scientific discovery.
- Saved results are explanatory research evidence, not a peer-reviewed finding.

Read `ARCHITECTURE_BLUEPRINT.md` for the production design and experimental go/no-go gates.
