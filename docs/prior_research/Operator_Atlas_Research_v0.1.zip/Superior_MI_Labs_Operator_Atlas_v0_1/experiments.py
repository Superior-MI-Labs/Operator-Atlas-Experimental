"""Superior MI Labs | Operator Atlas v0.1: small reproducible falsification probes.
Synthetic operator codecs are NOT a trained language model.
Run: python experiments.py
"""
import csv,itertools,json,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
N=48

def relative_error(A,B):
    return float(np.linalg.norm(A-B)/max(np.linalg.norm(A),1e-15))

def low_rank(W,r):
    U,S,Vh=np.linalg.svd(W,full_matrices=False)
    return (U[:,:r]*S[:r])@Vh[:r,:]

def encode_candidates(W):
    C=[('fp32',W.copy(),W.size*4)]
    s=float(np.max(np.abs(W)))/127.0
    Q=np.round(W/s).clip(-127,127).astype(np.int8) if s else np.zeros(W.shape,dtype=np.int8)
    C.append(('int8',Q.astype(np.float32)*s,Q.size+4))
    U,S,Vh=np.linalg.svd(W,full_matrices=False)
    for r in [2,4,6,8,12]:
        approx=(U[:,:r]*S[:r])@Vh[:r,:]
        nbytes=(N*r+r*N)*4
        C.append((f'rank{r}',approx,nbytes))
        residual=W-approx
        flat=np.argsort(-np.abs(residual).ravel())
        for k in [12,24,48]:
            sel=flat[:k]
            corrected=approx.copy().ravel(); corrected[sel]+=residual.ravel()[sel]
            C.append((f'rank{r}+sparse{k}',corrected.reshape(W.shape),nbytes+k*8))
    # Robust alternating low-rank + sparse decomposition. This is a heuristic,
    # not guaranteed matrix recovery, with indices + values charged as bytes.
    for r in [2,4]:
        for k in [24,48]:
            S=np.zeros_like(W); L=low_rank(W,r)
            for _ in range(40):
                residue=W-L
                keep=np.argpartition(np.abs(residue).ravel(),-k)[-k:]
                Snew=np.zeros(W.size,dtype=W.dtype)
                Snew[keep]=residue.ravel()[keep]
                Snew=Snew.reshape(W.shape)
                L=low_rank(W-Snew,r)
                S=Snew
            C.append((f'robust-rank{r}+sparse{k}',L+S, (N*r+r*N)*4+k*8))
    return C

def source_tile(kind,rng):
    U,_=np.linalg.qr(rng.standard_normal((N,12)))
    V,_=np.linalg.qr(rng.standard_normal((N,12)))
    if kind=='rank2': return (U[:,:2] @ np.diag([7.,4.]) @ V[:,:2].T)
    if kind=='rank6': return (U[:,:6] @ np.diag([8.,7.,6.,5.,4.,3.]) @ V[:,:6].T)
    if kind=='rank2+sparse':
        W=U[:,:2] @ np.diag([7.,4.]) @ V[:,:2].T
        idx=rng.choice(N*N,18,replace=False)
        W.ravel()[idx]+=rng.choice([-1.,1.],size=18)*rng.uniform(0.4,0.8,size=18)
        return W
    if kind=='random': return rng.standard_normal((N,N)) / np.sqrt(N)
    raise ValueError(kind)

def codec_experiment():
    rows=[]
    for seed in range(5):
        rng=np.random.default_rng(seed+131)
        for kind in ['rank2','rank6','rank2+sparse','random']:
            W=source_tile(kind,rng).astype(np.float32)
            Xval=rng.standard_normal((N,100))
            Xtst=rng.standard_normal((N,400))
            candidates=encode_candidates(W)
            for threshold in [.005,.02]:
                ok=[(name,bytes_,relative_error(W@Xval,A@Xval),relative_error(W@Xtst,A@Xtst),relative_error(W,A)) for name,A,bytes_ in candidates if relative_error(W@Xval,A@Xval)<=threshold]
                # Minimize bytes. Tie-break by validation error, not test.
                pick=min(ok,key=lambda v:(v[1],v[2]))
                rows.append({'seed':seed,'case':kind,'tolerance':threshold,'representation':pick[0],'bytes':pick[1],'ratio_vs_fp32':round((W.size*4)/pick[1],3),'test_output_error':pick[3],'weight_error':pick[4]})
    with (ROOT/'operator_codec_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,rows[0].keys());writer.writeheader();writer.writerows(rows)
    summary={}
    for tol in [.005,.02]:
        summary[str(tol)]={}
        for case in ['rank2','rank6','rank2+sparse','random']:
            r=[x for x in rows if x['case']==case and x['tolerance']==tol]
            summary[str(tol)][case]={'selected':[x['representation'] for x in r], 'mean_bytes':float(np.mean([x['bytes'] for x in r])),'mean_test_error':float(np.mean([x['test_output_error'] for x in r])),'mean_compression':float(np.mean([x['ratio_vs_fp32'] for x in r]))}
    return summary

BASIS=[('1',lambda x:np.ones_like(x)),('x',lambda x:x),('x²',lambda x:x*x),('x³',lambda x:x*x*x),('sin(x)',np.sin),('cos(x)',np.cos),('sin(2x)',lambda x:np.sin(2*x)),('cos(2x)',lambda x:np.cos(2*x))]
def discover(x,y):
    Phi=np.column_stack([f(x) for _,f in BASIS]); n=len(x)
    best=None
    for k in range(1,4):
        for cols in itertools.combinations(range(len(BASIS)),k):
            coef=np.linalg.lstsq(Phi[:,cols],y,rcond=None)[0]
            mse=np.mean((y-Phi[:,cols]@coef)**2)
            bic=n*math.log(max(mse,1e-14))+k*math.log(n)
            if best is None or bic<best[0]: best=(bic,cols,coef)
    return best[1],best[2]
def predict_equation(x,cols,coef):
    Phi=np.column_stack([f(x) for _,f in BASIS])
    return Phi[:,cols]@coef

def discover_experiment():
    rows=[]
    for seed in range(5):
        rng=np.random.default_rng(seed+1001)
        for case in ['structured','random']:
            # Structured function intentionally belongs to supplied grammar.
            yfn=lambda x:1.4-0.65*x*x+2.2*np.sin(2*x)
            x=rng.uniform(-2,2,size=60); xtest=rng.uniform(-2,2,size=1000)
            noise=rng.normal(0,.025,60)
            y=yfn(x)+noise if case=='structured' else rng.standard_normal(60)
            yt=yfn(xtest) if case=='structured' else rng.standard_normal(1000)
            cols,coef=discover(x,y)
            yhat=predict_equation(xtest,cols,coef)
            mean=np.full_like(yt,np.mean(y))
            rows.append({'seed':seed,'case':case,'terms':','.join(BASIS[i][0] for i in cols),'equation_rmse':float(np.sqrt(np.mean((yt-yhat)**2))),'mean_baseline_rmse':float(np.sqrt(np.mean((yt-mean)**2)))})
    with (ROOT/'equation_search_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,rows[0].keys());writer.writeheader();writer.writerows(rows)
    summary={}
    for case in ['structured','random']:
        a=[r for r in rows if r['case']==case]
        summary[case]={'learned_terms':[r['terms'] for r in a],'avg_rmse':float(np.mean([r['equation_rmse'] for r in a])),'avg_mean_baseline_rmse':float(np.mean([r['mean_baseline_rmse'] for r in a]))}
    return summary

def shift_experiment():
    rows=[]
    for seed in range(5):
        rng=np.random.default_rng(800+seed)
        W=(rng.standard_normal((N,N))/np.sqrt(N)).astype(np.float32)
        U,_=np.linalg.qr(rng.standard_normal((N,4)))
        U=U.astype(np.float32)
        # Factor pair represents (W @ U) and U.T in stored float32.
        A=(W@U)@U.T
        z=rng.standard_normal((4,200)); X_in=U@z
        X_out=rng.standard_normal((N,200))
        rows.append({'seed':seed,'in_distribution_error':relative_error(W@X_in,A@X_in),'shifted_error':relative_error(W@X_out,A@X_out),'factor_bytes':2*N*4*4,'dense_bytes':W.size*4})
    with (ROOT/'distribution_shift_results.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,rows[0].keys());writer.writeheader();writer.writerows(rows)
    return {'mean_in_distribution_error':float(np.mean([a['in_distribution_error'] for a in rows])),'mean_shifted_error':float(np.mean([a['shifted_error'] for a in rows])),'factor_bytes':rows[0]['factor_bytes'],'dense_bytes':rows[0]['dense_bytes']}

if __name__=='__main__':
    out={'description':'Synthetic operator encoding, basis search, and activation-subspace stress tests; no language-model training.', 'codec':codec_experiment(), 'discovery':discover_experiment(),'distribution_shift':shift_experiment()}
    (ROOT/'results.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
    print(json.dumps(out,indent=2,ensure_ascii=False))
